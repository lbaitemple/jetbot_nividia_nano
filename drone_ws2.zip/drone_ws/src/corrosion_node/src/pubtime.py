#!/usr/bin/env python3
# license removed for brevity
import rospy, rospkg
from std_msgs.msg import String
from sensor_msgs.msg import Image
from D435_corrosion_rosutil import *
from cv_bridge import CvBridge, CvBridgeError 
import numpy as np


class CorrossionClassifier: 
    def __init__(self, width=300, height=300, model= "corrosion_trt1.pth"):
        self.package = "corrosion_node"
        folder = rospkg.RosPack().get_path(self.package) 
        fmodel = "{}/{}".format(folder, model)
        self.pub = rospy.Publisher('chatter', String, queue_size=10)
        self.pubimg= rospy.Publisher('image', Image, queue_size=10)
        self.camera = Camera(width,height)
        self.camera.loadmodel(fmodel)
        self.bridge = CvBridge()
        rospy.init_node('talker', anonymous=True)
        rate = rospy.Rate(10) # 10hz
        cnt = 0
        while not rospy.is_shutdown():
            hello_str = "hello world %s" % rospy.get_time()
            ### get a frame from the camera
            cvalue = self.camera.getcorrosionvalue()
            #self.camera.get_frame()
            #image_message = self.bridge.cv2_to_imgmsg(self.camera.color_image)
            #np.asarray(bridge.imgmsg_to_cv2(msg, 'bgr8'))
            #self.pubimg.publish(image_message)
            self.pub.publish("corriosn value is: {} ".format(cvalue))
            if (cvalue > 100):
                fn = '/home/jetbot/drone/img_{}.png'.format(cnt)
                print(fn)
                self.camera.saveimage(filename = fn)
                cnt = cnt + 1
        
            rate.sleep()
            
    def stop_camera(self):
        self.camera.stopcamera()

if __name__ == '__main__':
    try:
        mfile = "/model/corrosion_trt1.pth" 
        cc = CorrossionClassifier(model= mfile)
        
    except rospy.ROSInterruptException:
        cc.stop_camera()