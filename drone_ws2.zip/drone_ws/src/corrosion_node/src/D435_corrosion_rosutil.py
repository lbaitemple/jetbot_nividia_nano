#import display module
#from IPython.display import display
#import ipywidgets.widgets as widgets
#from jetbot import bgr8_to_jpeg
#import ipywidgets


#import pyrealsense module
from torch2trt import TRTModule

import sys
sys.path.append('/usr/local/lib/python2.7/pyrealsense2')
import pyrealsense2 as rs  

#import torch to Tensorrt module
import torch

#import threading
import threading
import time
import imageio
#import modules for the normalization of the preprocess
import cv2, PIL
import numpy as np
import torchvision
import torchvision.transforms as T

#import modules for buttun
#from ipywidgets import Button, Layout, HBox
#from IPython.display import display



#define a class for easier to use camera display
class Camera: 
    #activate the realsense camera
    def __init__(self, width=150, height=150):
        
        # Configure depth and color streams
        self.pipeline = rs.pipeline()
        self.config = rs.config()

        # Get device product line for setting a supporting resolution
        pipeline_wrapper = rs.pipeline_wrapper(self.pipeline)
        pipeline_profile = self.config.resolve(pipeline_wrapper)
        device = pipeline_profile.get_device()
        device_product_line = str(device.get_info(rs.camera_info.product_line))
        
        self.config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
        self.config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)

        # Start streaming
        self.pipeline.start(self.config)
        print("The pipeline is ready")
        #self.display(width,height)
        
    #load the model
    def loadmodel(self,modelname):
        self.model_trt = TRTModule()
        self.model_trt.load_state_dict(torch.load(modelname))
        print(modelname, "is load successfully")
    
    #create a image box and define the size
#    def display(self,width,height):
#        self.seg_image = ipywidgets.Image(format='jpeg', width=width, height=height)
#        self.depthframe_image = ipywidgets.Image(format='jpeg', width=width, height=height)
#        self.colorframe_image = ipywidgets.Image(format='jpeg', width=width, height=height)
#        self.im_value = ipywidgets.Label('im value:', layout=ipywidgets.Layout(width='100%'))
#        display(widgets.VBox([widgets.HBox([self.depthframe_image, self.colorframe_image, self.seg_image]),self.im_value]))        

    #get the frame of the images from realsense camera
    def get_frame(self):
        self.frames = self.pipeline.wait_for_frames()
        self.depth_frame = self.frames.get_depth_frame()
        self.color_frame = self.frames.get_color_frame()
        colorizer = rs.colorizer()
        self.depth_image = np.asanyarray(colorizer.colorize(self.depth_frame).get_data())
        color_image = np.asanyarray(self.color_frame.get_data())
        r, g, b = cv2.split(color_image)
        self.color_image = cv2.merge((b, g, r))
        #self.color_image = cv2.cvtColor(yuyv_image, cv2.COLOR_YUV2BGR_YUY2)
        return self.depth_image, self.color_image

    #image normalization and preprocess for the model_trt
    def preprocess(self,camera_value):
        global device, normalize
        device = torch.device('cuda')
        mean = 255.0 * np.array([0.485, 0.456, 0.406])
        stdev = 255.0 * np.array([0.229, 0.224, 0.225])
        normalize = torchvision.transforms.Normalize(mean, stdev)
        x = camera_value
        x = cv2.resize(x, (224, 224))
        x = cv2.cvtColor(x, cv2.COLOR_BGR2RGB)
        x = x.transpose((2, 0, 1))
        x = torch.from_numpy(x).float()
        x = normalize(x)
        x = x.to(device)
        x = x[None, ...]
        return x
    
    #decode the map for different classes
    def decode_segmap(self,image, nc=21):
        label_colors = np.array([(127,127,127),  # 0=background
                   # 1=aeroplane, 2=bicycle, 3=bird, 4=boat, 5=bottle
                   (128, 0, 0), (0, 128, 0), (128, 128, 0), (0, 0, 128), (128, 0, 128),
                   # 6=bus, 7=car, 8=cat, 9=chair, 10=cow
                   (0, 128, 128), (128, 128, 128), (64, 0, 0), (192, 0, 0), (64, 128, 0),
                   # 11=dining table, 12=dog, 13=horse, 14=motorbike, 15=person
                   (192, 128, 0), (64, 0, 128), (192, 0, 128), (64, 128, 128), (192, 128, 128),
                   # 16=potted plant, 17=sheep, 18=sofa, 19=train, 20=tv/monitor
                   (0, 64, 0), (128, 64, 0), (0, 192, 0), (128, 192, 0), (0, 64, 128)])

        r = np.zeros_like(image).astype(np.uint8)
        g = np.zeros_like(image).astype(np.uint8)
        b = np.zeros_like(image).astype(np.uint8)
        image[image == 1] = 10
        for l in range(0, nc):
            idx = image == l
            r[idx] = label_colors[l, 2]
            g[idx] = label_colors[l, 1]
            b[idx] = label_colors[l, 0]

        rgb = np.stack([r, g, b], axis=2)
        return rgb
    
    #execution for image segmentation
#    def execute(self,change):
#        image = change['new']
#        self.depth_frame, self.color_frame = self.get_frame()
#        output = self.model_trt(self.preprocess(self.color_frame).half())[0].detach().cpu().float().numpy()
#        im=((output.squeeze())>0.6).astype(int)
 #       self.im_value.value = str(np.sum(im))
#        self.detectcorrosion = str(np.sum(im))
#        mask=self.decode_segmap(im)
#        self.seg_image.value = bgr8_to_jpeg(mask)
#        self.depthframe_image.value = bgr8_to_jpeg(self.depth_frame)
#        self.colorframe_image.value = bgr8_to_jpeg(self.color_frame)
        

    def saveimage(self, filename):
        #color_image = np.asanyarray(self.color_frame.get_data())
        imageio.imwrite(filename, self.color_image)
        
    
    def getcorrosionvalue(self):
        self.depth_frame, self.color_frame = self.get_frame()
        output = self.model_trt(self.preprocess(self.color_frame).half())[0].detach().cpu().float().numpy()
        im=((output.squeeze())>0.6).astype(int)
 #       self.im_value.value = str(np.sum(im))
        self.detectcorrosion = np.sum(im)
        return self.detectcorrosion 
        
        
    #threading for stop and restart
#    def doit(self):
#        t = threading.currentThread()

#        self.depth_frame = self.get_frame()
#        self.color_frame = self.get_frame()
#        try:
#            while getattr(t, "do_run", True):
#                self.execute({'new': self.color_frame})
#        except KeyboardInterrupt:
#            print("The program was interupted by the user. Closing the program...")
            
#    def run(self):
#        self.t = threading.Thread(target=self.doit)
#        self.t.start()
    
#    def stop_thread(self):  
#        self.t.do_run = False 
        
#    def restart_thread(self):
#        self.t = threading.Thread(target=self.doit)
#        self.t.start()
    
    def stop_camera(self): 
 #       self.t.do_run = False 
        self.pipeline.stop()   

        
        def click_start(b):
            self.run()
            print("start")
        def click_stop_thread(b):
            self.stop_thread()
            print("stop_thread")
        def click_restart_thread(b):
            self.restart_thread()
            print("restart_thread")
        def click_stop_camera(b):
            self.stop_camera()
            print("close the pineline")
        start.on_click(click_start)
        stop_thread.on_click(click_stop_thread)
        restart_thread.on_click(click_restart_thread)
        stop_camera.on_click(click_stop_camera) 
        display(HBox([start, stop_thread, restart_thread, stop_camera]))
