from navsea.biofouling.classify import BiofoulingClassfier
